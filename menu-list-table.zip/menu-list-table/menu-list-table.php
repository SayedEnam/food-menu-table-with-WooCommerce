<?php
/*
Plugin Name: Menu List Table
Plugin URI:  orbeen.com
Description: Premium menu with Full Button Dimension Controls (Add, View, Load More), Floating Cart, Vertical Layouts, and Accessibility.
Version:     58.0
Author:      Sayed
Author URI:  orbeen.com
License:     GPL2
*/

if (! defined('ABSPATH')) {
    exit;
}

// ------------------------------------------------------------------
// 1. SETTINGS LINK
// ------------------------------------------------------------------
function mlt_add_settings_link($links)
{
    array_unshift($links, '<a href="admin.php?page=mlt-settings">Settings</a>');
    return $links;
}
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'mlt_add_settings_link');

// ------------------------------------------------------------------
// 2. SCRIPTS
// ------------------------------------------------------------------
function mlt_enqueue_admin_scripts($hook)
{
    if ('toplevel_page_mlt-settings' !== $hook) {
        return;
    }
    wp_enqueue_media();
}
add_action('admin_enqueue_scripts', 'mlt_enqueue_admin_scripts');

// ------------------------------------------------------------------
// 3. CART FRAGMENTS
// ------------------------------------------------------------------
function mlt_cart_fragments($fragments)
{
    if (! function_exists('WC')) return $fragments;

    $count = WC()->cart->get_cart_contents_count();
    $total = WC()->cart->get_cart_total();
    $class = WC()->cart->is_empty() ? '' : 'mlt-visible';

    ob_start();
?>
    <div class="mlt-floating-cart <?php echo esc_attr($class); ?>">
        <span class="mlt-cart-info">
            <span class="mlt-cart-count"><?php echo esc_html($count); ?> Items</span> &ndash;
            <span class="mlt-cart-total"><?php echo wp_kses_post($total); ?></span>
        </span>
        <div class="mlt-cart-right-group">
            <a href="<?php echo esc_url(wc_get_cart_url()); ?>">View Cart &rarr;</a>
            <span class="mlt-cart-close" title="Close">&times;</span>
        </div>
    </div>
<?php
    $fragments['.mlt-floating-cart'] = ob_get_clean();
    return $fragments;
}
add_filter('woocommerce_add_to_cart_fragments', 'mlt_cart_fragments', 10, 1);

// ------------------------------------------------------------------
// 4. ADD TAB ACTION
// ------------------------------------------------------------------
function mlt_handle_actions()
{
    if (is_admin() && isset($_GET['mlt_action']) && $_GET['mlt_action'] === 'add_new_tab') {
        if (!current_user_can('manage_options')) return;
        $options = get_option('mlt_options');
        if (!isset($options['tabs']) || !is_array($options['tabs'])) $options['tabs'] = [];
        $options['tabs'][] = ['title' => 'New Section', 'desc' => '', 'two_col' => '0', 'items' => []];
        update_option('mlt_options', $options);
        wp_redirect(admin_url('admin.php?page=mlt-settings'));
        exit;
    }
}
add_action('admin_init', 'mlt_handle_actions');

// ------------------------------------------------------------------
// 5. SETTINGS PAGE
// ------------------------------------------------------------------
function mlt_add_admin_menu()
{
    add_menu_page('Menu List Table', 'Menu List Table', 'manage_options', 'mlt-settings', 'mlt_options_page_html', 'dashicons-cart', 20);
}
add_action('admin_menu', 'mlt_add_admin_menu');

function mlt_settings_init()
{
    register_setting('mlt_plugin_group', 'mlt_options', 'mlt_sanitize_options');
}
add_action('admin_init', 'mlt_settings_init');

function mlt_sanitize_options($input)
{
    if (!current_user_can('manage_options')) return get_option('mlt_options');

    $clean_data = [];
    $clean_data['layout_mode'] = sanitize_text_field($input['layout_mode'] ?? 'horizontal');

    // Colors
    $clean_data['btn_bg']     = sanitize_hex_color($input['btn_bg'] ?? '#222222');
    $clean_data['btn_text']   = sanitize_hex_color($input['btn_text'] ?? '#ffffff');
    $clean_data['tab_active'] = sanitize_hex_color($input['tab_active'] ?? '#0073aa');

    // Backgrounds & Borders
    $clean_data['content_bg'] = sanitize_text_field($input['content_bg'] ?? '#ffffff');
    $clean_data['wrapper_bg'] = sanitize_text_field($input['wrapper_bg'] ?? '');
    $clean_data['tab_bg']     = sanitize_text_field($input['tab_bg'] ?? '#ffffff');
    $clean_data['sidebar_bg'] = sanitize_text_field($input['sidebar_bg'] ?? '#f8f9fa');
    $clean_data['border_col'] = sanitize_hex_color($input['border_col'] ?? '#eeeeee');
    $clean_data['wrap_border'] = sanitize_hex_color($input['wrap_border'] ?? '');
    $clean_data['cont_border'] = sanitize_hex_color($input['cont_border'] ?? '#f9f9f9');

    // Text Colors
    $clean_data['name_col']   = sanitize_hex_color($input['name_col'] ?? '#333333');
    $clean_data['price_col']  = sanitize_hex_color($input['price_col'] ?? '#0073aa');
    $clean_data['desc_col']   = sanitize_hex_color($input['desc_col'] ?? '#777777');
    $clean_data['note_col']   = sanitize_hex_color($input['note_col'] ?? '#555555');
    $clean_data['main_desc_col'] = sanitize_hex_color($input['main_desc_col'] ?? '#555555');

    // General Misc
    $clean_data['font_size']  = absint($input['font_size'] ?? 17);
    $clean_data['tab_font_size'] = absint($input['tab_font_size'] ?? 15);
    $clean_data['btn_label']  = sanitize_text_field($input['btn_label'] ?? 'Add');

    // Add Button Dimensions
    $clean_data['btn_width']  = sanitize_text_field($input['btn_width'] ?? '');
    $clean_data['btn_height'] = sanitize_text_field($input['btn_height'] ?? '');

    // Load More Settings
    $clean_data['load_more_enable'] = isset($input['load_more_enable']) ? '1' : '0';
    $clean_data['load_more_label'] = sanitize_text_field($input['load_more_label'] ?? 'Load More');
    $clean_data['load_more_bg']    = sanitize_hex_color($input['load_more_bg'] ?? '#f1f1f1');
    $clean_data['load_more_text']  = sanitize_hex_color($input['load_more_text'] ?? '#333333');
    $clean_data['load_more_size']  = absint($input['load_more_size'] ?? 14);
    $clean_data['load_more_width'] = sanitize_text_field($input['load_more_width'] ?? ''); // NEW
    $clean_data['load_more_height'] = sanitize_text_field($input['load_more_height'] ?? ''); // NEW

    // View Button Settings
    $clean_data['view_btn_label'] = sanitize_text_field($input['view_btn_label'] ?? 'View Full Menu');
    $clean_data['view_btn_bg']    = sanitize_hex_color($input['view_btn_bg'] ?? '#222');
    $clean_data['view_btn_text']  = sanitize_hex_color($input['view_btn_text'] ?? '#fff');
    $clean_data['view_btn_size']  = absint($input['view_btn_size'] ?? 14);
    $clean_data['view_btn_width'] = sanitize_text_field($input['view_btn_width'] ?? ''); // NEW
    $clean_data['view_btn_height'] = sanitize_text_field($input['view_btn_height'] ?? ''); // NEW

    $clean_data['tabs'] = [];
    if (isset($input['tabs']) && is_array($input['tabs'])) {
        foreach ($input['tabs'] as $tab) {
            if (isset($tab['remove']) && $tab['remove'] == '1') continue;

            $clean_tab = [
                'title'   => sanitize_text_field($tab['title']),
                'desc'    => wp_kses_post($tab['desc']),
                'two_col' => (isset($tab['two_col']) && $tab['two_col'] == '1') ? '1' : '0',
                'view_url' => sanitize_text_field($tab['view_url'] ?? ''),
                'items'   => []
            ];

            if (isset($tab['items']) && is_array($tab['items'])) {
                foreach ($tab['items'] as $item) {
                    $name = isset($item['name']) ? sanitize_text_field($item['name']) : '';
                    $raw_price = isset($item['price']) ? sanitize_text_field($item['price']) : '';
                    $product_id = isset($item['product_id']) ? intval($item['product_id']) : 0;
                    $image = isset($item['image']) ? esc_url_raw($item['image']) : '';
                    $note = isset($item['note']) ? sanitize_text_field($item['note']) : '';
                    $desc = isset($item['desc']) ? sanitize_textarea_field($item['desc']) : '';

                    if (empty($name) && empty($product_id)) continue;

                    if ($product_id > 0 && function_exists('wc_get_product')) {
                        $product = wc_get_product($product_id);
                        if ($product && !empty($raw_price)) {
                            $clean_price = preg_replace('/[^0-9.]/', '', str_replace(',', '.', $raw_price));
                            if (is_numeric($clean_price)) {
                                try {
                                    $product->set_regular_price($clean_price);
                                    $product->set_price($clean_price);
                                    $product->save();
                                    wc_delete_product_transients($product_id);
                                } catch (Exception $e) {
                                }
                            }
                        }
                    }

                    $clean_tab['items'][] = [
                        'name' => $name,
                        'price' => $raw_price,
                        'product_id' => $product_id,
                        'image' => $image,
                        'note' => $note,
                        'desc' => $desc
                    ];
                }
            }
            $clean_data['tabs'][] = $clean_tab;
        }
    }
    return $clean_data;
}

function mlt_options_page_html()
{
    if (!current_user_can('manage_options')) return;

    $product_options_html = '<option value="" data-price="">-- Select a Product --</option>';
    $args = array('post_type' => 'product', 'posts_per_page' => -1, 'post_status' => 'publish', 'orderby' => 'title', 'order' => 'ASC');
    $products = get_posts($args);
    $product_prices_map = [];
    if ($products) {
        foreach ($products as $prod) {
            $wc_product = function_exists('wc_get_product') ? wc_get_product($prod->ID) : false;
            $raw_price = $wc_product ? $wc_product->get_price() : '';
            $product_prices_map[$prod->ID] = $raw_price;
            $product_options_html .= '<option value="' . $prod->ID . '" data-price="' . esc_attr($raw_price) . '">' . esc_html($prod->post_title) . '</option>';
        }
    }

    $options = get_option('mlt_options');
    $tabs = $options['tabs'] ?? [];

    // Defaults
    $c_btn_bg     = $options['btn_bg'] ?? '#222222';
    $c_btn_text   = $options['btn_text'] ?? '#ffffff';
    $c_tab_active = $options['tab_active'] ?? '#0073aa';
    $c_content_bg = $options['content_bg'] ?? '#ffffff';
    $c_wrapper_bg = $options['wrapper_bg'] ?? '';
    $c_tab_bg     = $options['tab_bg'] ?? '#ffffff';
    $c_sidebar_bg = $options['sidebar_bg'] ?? '#f8f9fa';
    $c_border_col = $options['border_col'] ?? '#eeeeee';
    $c_wrap_border = $options['wrap_border'] ?? '';
    $c_cont_border = $options['cont_border'] ?? '#f9f9f9';
    $c_name_col   = $options['name_col'] ?? '#333333';
    $c_price_col  = $options['price_col'] ?? '#0073aa';
    $c_desc_col   = $options['desc_col'] ?? '#777777';
    $c_note_col   = $options['note_col'] ?? '#555555';
    $c_main_desc_col = $options['main_desc_col'] ?? '#555555';
    $c_font_size  = $options['font_size'] ?? 17;
    $c_tab_font_size = $options['tab_font_size'] ?? 15;
    $c_btn_label  = $options['btn_label'] ?? 'Add';
    $c_layout_mode = $options['layout_mode'] ?? 'horizontal';

    $c_btn_width  = $options['btn_width'] ?? '';
    $c_btn_height = $options['btn_height'] ?? '';

    // Load More Defaults
    $c_lm_enable = (isset($options['load_more_enable']) && $options['load_more_enable'] == '1') ? 'checked' : '';
    $c_lm_label = $options['load_more_label'] ?? 'Load More';
    $c_lm_bg    = $options['load_more_bg'] ?? '#f1f1f1';
    $c_lm_text  = $options['load_more_text'] ?? '#333333';
    $c_lm_size  = $options['load_more_size'] ?? 14;
    $c_lm_width = $options['load_more_width'] ?? '';
    $c_lm_height = $options['load_more_height'] ?? '';

    // View Button Defaults
    $c_vb_label = $options['view_btn_label'] ?? 'View Full Menu';
    $c_vb_bg    = $options['view_btn_bg'] ?? '#222';
    $c_vb_text  = $options['view_btn_text'] ?? '#fff';
    $c_vb_size  = $options['view_btn_size'] ?? 14;
    $c_vb_width = $options['view_btn_width'] ?? '';
    $c_vb_height = $options['view_btn_height'] ?? '';
?>
    <div class="wrap">
        <h1>Menu List Table Settings</h1>

        <form action="options.php" method="post" id="mlt-form">
            <?php settings_fields('mlt_plugin_group'); ?>

            <style>
                .mlt-tabs-nav {
                    display: flex;
                    border-bottom: 1px solid #ccc;
                    background: #fff;
                    margin-bottom: 20px;
                }

                .mlt-tab-item {
                    padding: 12px 20px;
                    cursor: pointer;
                    border-right: 1px solid #eee;
                    font-weight: 600;
                    color: #555;
                    background: #f7f7f7;
                }

                .mlt-tab-item:hover {
                    background: #f0f0f0;
                    color: #000;
                }

                .mlt-tab-item.active {
                    background: #fff;
                    color: #0073aa;
                    border-bottom: 2px solid #0073aa;
                    margin-bottom: -1px;
                }

                .mlt-tab-pane {
                    display: none;
                    background: #fff;
                    padding: 25px;
                    border: 1px solid #ccc;
                    border-top: none;
                }

                .mlt-tab-pane.active {
                    display: grid;
                    grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
                    gap: 20px;
                }

                .mlt-control-row {
                    display: flex;
                    flex-direction: column;
                    gap: 5px;
                    margin-bottom: 5px;
                }

                .mlt-control-row label {
                    font-weight: 600;
                    font-size: 12px;
                    color: #333;
                }

                .mlt-control-row input[type="color"] {
                    cursor: pointer;
                    height: 30px;
                    width: 100%;
                    border: 1px solid #ddd;
                    padding: 2px;
                }

                .mlt-control-row input[type="text"],
                .mlt-control-row input[type="number"],
                .mlt-control-row select {
                    width: 100%;
                    padding: 6px;
                    border: 1px solid #ccc;
                    border-radius: 4px;
                }

                .mlt-hidden {
                    display: none !important;
                }

                .mlt-admin-box {
                    margin-bottom: 15px;
                    border: 1px solid #ccd0d4;
                    background: #fff;
                    max-width: 950px;
                }

                .mlt-admin-header {
                    padding: 15px;
                    background: #f9f9f9;
                    cursor: pointer;
                    display: flex;
                    justify-content: space-between;
                    font-weight: bold;
                }

                .mlt-admin-content {
                    display: none;
                    padding: 20px;
                }

                .mlt-admin-box.open .mlt-admin-content {
                    display: block;
                }

                .mlt-item-row {
                    display: flex;
                    gap: 10px;
                    margin-bottom: 15px;
                    align-items: flex-start;
                    background: #fdfdfd;
                    padding: 15px;
                    border: 1px solid #eee;
                    flex-wrap: wrap;
                }

                .mlt-item-row label {
                    font-size: 11px;
                    color: #666;
                    display: block;
                    margin-bottom: 4px;
                    font-weight: 600;
                }

                .mlt-item-row select,
                .mlt-item-row input,
                .mlt-item-row textarea {
                    width: 100%;
                }

                .mlt-btn-remove {
                    color: #a00;
                    cursor: pointer;
                    font-size: 12px;
                    margin-top: 5px;
                    text-decoration: underline;
                    display: inline-block;
                }

                .mlt-image-wrapper {
                    display: flex;
                    align-items: center;
                    gap: 10px;
                }

                .mlt-image-preview {
                    width: 40px;
                    height: 40px;
                    border-radius: 4px;
                    object-fit: cover;
                    border: 1px solid #ddd;
                    background: #eee;
                }

                .mlt-upload-btn {
                    font-size: 12px !important;
                }
            </style>

            <div class="mlt-settings-container">
                <div class="mlt-tabs-nav">
                    <div class="mlt-tab-item active" onclick="mltSwitchAdminTab(event, 'tab-general')">⚙️ General</div>
                    <div class="mlt-tab-item" onclick="mltSwitchAdminTab(event, 'tab-text')">🎨 Text Colors</div>
                    <div class="mlt-tab-item" onclick="mltSwitchAdminTab(event, 'tab-containers')">🖼️ Containers</div>
                    <div class="mlt-tab-item" onclick="mltSwitchAdminTab(event, 'tab-buttons')">🖱️ Tab Buttons & UI</div>
                    <div class="mlt-tab-item" onclick="mltSwitchAdminTab(event, 'tab-loadmore')">🔃 Load More Button</div>
                    <div class="mlt-tab-item" onclick="mltSwitchAdminTab(event, 'tab-viewbtn')">🔗 View Button</div>
                </div>

                <div id="tab-general" class="mlt-tab-pane active">
                    <div class="mlt-control-row">
                        <label>Tab Layout</label>
                        <select name="mlt_options[layout_mode]" id="mlt-layout-select">
                            <option value="horizontal" <?php selected($c_layout_mode, 'horizontal'); ?>>Horizontal (Default)</option>
                            <option value="vertical" <?php selected($c_layout_mode, 'vertical'); ?>>Vertical Sidebar</option>
                        </select>
                    </div>
                    <div class="mlt-control-row <?php echo ($c_layout_mode !== 'vertical') ? 'mlt-hidden' : ''; ?>" id="mlt-sidebar-bg-row">
                        <label>Sidebar Column BG</label>
                        <div style="display:flex; gap:5px;">
                            <input type="text" name="mlt_options[sidebar_bg]" value="<?php echo esc_attr($c_sidebar_bg); ?>" placeholder="#f8f9fa">
                            <input type="color" value="<?php echo esc_attr($c_sidebar_bg ? $c_sidebar_bg : '#f8f9fa'); ?>" onchange="this.previousElementSibling.value=this.value" style="width:40px;">
                        </div>
                    </div>
                    <div class="mlt-control-row">
                        <label>Order Button Label</label>
                        <input type="text" name="mlt_options[btn_label]" value="<?php echo esc_attr($c_btn_label); ?>">
                    </div>
                    <div class="mlt-control-row">
                        <label>Item Font Size (px)</label>
                        <input type="number" name="mlt_options[font_size]" value="<?php echo esc_attr($c_font_size); ?>" min="10">
                    </div>
                    <div class="mlt-control-row">
                        <label>Tab Button Font Size (px)</label>
                        <input type="number" name="mlt_options[tab_font_size]" value="<?php echo esc_attr($c_tab_font_size); ?>" min="10">
                    </div>
                </div>

                <div id="tab-text" class="mlt-tab-pane">
                    <div class="mlt-control-row">
                        <label>Item Name Color</label>
                        <input type="color" name="mlt_options[name_col]" value="<?php echo esc_attr($c_name_col); ?>">
                    </div>
                    <div class="mlt-control-row">
                        <label>Price Color</label>
                        <input type="color" name="mlt_options[price_col]" value="<?php echo esc_attr($c_price_col); ?>">
                    </div>
                    <div class="mlt-control-row">
                        <label>Item Description Color</label>
                        <input type="color" name="mlt_options[desc_col]" value="<?php echo esc_attr($c_desc_col); ?>">
                    </div>
                    <div class="mlt-control-row">
                        <label>Short Note Color</label>
                        <input type="color" name="mlt_options[note_col]" value="<?php echo esc_attr($c_note_col); ?>">
                    </div>
                    <div class="mlt-control-row">
                        <label>Tab Intro Text Color</label>
                        <input type="color" name="mlt_options[main_desc_col]" value="<?php echo esc_attr($c_main_desc_col); ?>">
                    </div>
                </div>

                <div id="tab-containers" class="mlt-tab-pane">
                    <div class="mlt-control-row">
                        <label>Wrapper Background</label>
                        <div style="display:flex; gap:5px;">
                            <input type="text" name="mlt_options[wrapper_bg]" value="<?php echo esc_attr($c_wrapper_bg); ?>" placeholder="transparent">
                            <input type="color" value="<?php echo esc_attr($c_wrapper_bg ? $c_wrapper_bg : '#ffffff'); ?>" onchange="this.previousElementSibling.value=this.value" style="width:40px;">
                        </div>
                    </div>
                    <div class="mlt-control-row">
                        <label>Wrapper Border Color</label>
                        <input type="color" name="mlt_options[wrap_border]" value="<?php echo esc_attr($c_wrap_border); ?>">
                    </div>
                    <div class="mlt-control-row">
                        <label>Card/Content Background</label>
                        <div style="display:flex; gap:5px;">
                            <input type="text" name="mlt_options[content_bg]" value="<?php echo esc_attr($c_content_bg); ?>" placeholder="#ffffff">
                            <input type="color" value="<?php echo esc_attr($c_content_bg ? $c_content_bg : '#ffffff'); ?>" onchange="this.previousElementSibling.value=this.value" style="width:40px;">
                        </div>
                    </div>
                    <div class="mlt-control-row">
                        <label>Card Border Color</label>
                        <input type="color" name="mlt_options[cont_border]" value="<?php echo esc_attr($c_cont_border); ?>">
                    </div>
                    <div class="mlt-control-row">
                        <label>Inactive Tab Bar BG</label>
                        <input type="text" name="mlt_options[tab_bg]" value="<?php echo esc_attr($c_tab_bg); ?>" placeholder="#ffffff">
                    </div>
                    <div class="mlt-control-row">
                        <label>List Item Divider Line</label>
                        <input type="color" name="mlt_options[border_col]" value="<?php echo esc_attr($c_border_col); ?>">
                    </div>
                </div>

                <div id="tab-buttons" class="mlt-tab-pane">
                    <div class="mlt-control-row">
                        <label>Active Tab / Highlight</label>
                        <input type="color" name="mlt_options[tab_active]" value="<?php echo esc_attr($c_tab_active); ?>">
                    </div>
                    <div class="mlt-control-row">
                        <label>Add Button Background</label>
                        <input type="color" name="mlt_options[btn_bg]" value="<?php echo esc_attr($c_btn_bg); ?>">
                    </div>
                    <div class="mlt-control-row">
                        <label>Add Button Text Color</label>
                        <input type="color" name="mlt_options[btn_text]" value="<?php echo esc_attr($c_btn_text); ?>">
                    </div>
                    <div class="mlt-control-row">
                        <label>Add Button Width (px)</label>
                        <input type="text" name="mlt_options[btn_width]" value="<?php echo esc_attr($c_btn_width); ?>" placeholder="Auto">
                    </div>
                    <div class="mlt-control-row">
                        <label>Add Button Height (px)</label>
                        <input type="text" name="mlt_options[btn_height]" value="<?php echo esc_attr($c_btn_height); ?>" placeholder="Auto">
                    </div>
                </div>

                <div id="tab-loadmore" class="mlt-tab-pane">
                    <div class="mlt-control-row" style="grid-column: 1 / -1;">
                        <label style="font-size:14px; display:flex; align-items:center; gap:8px;">
                            <input type="checkbox" name="mlt_options[load_more_enable]" value="1" <?php echo $c_lm_enable; ?>>
                            Enable Load More Pagination
                        </label>
                        <p class="description">If enabled, only 6 items will show initially.</p>
                    </div>
                    <div class="mlt-control-row">
                        <label>Label Text</label>
                        <input type="text" name="mlt_options[load_more_label]" value="<?php echo esc_attr($c_lm_label); ?>">
                    </div>
                    <div class="mlt-control-row">
                        <label>Background Color</label>
                        <input type="color" name="mlt_options[load_more_bg]" value="<?php echo esc_attr($c_lm_bg); ?>">
                    </div>
                    <div class="mlt-control-row">
                        <label>Text Color</label>
                        <input type="color" name="mlt_options[load_more_text]" value="<?php echo esc_attr($c_lm_text); ?>">
                    </div>
                    <div class="mlt-control-row">
                        <label>Font Size (px)</label>
                        <input type="number" name="mlt_options[load_more_size]" value="<?php echo esc_attr($c_lm_size); ?>" min="10">
                    </div>
                    <div class="mlt-control-row">
                        <label>Width (px)</label>
                        <input type="text" name="mlt_options[load_more_width]" value="<?php echo esc_attr($c_lm_width); ?>" placeholder="Auto">
                    </div>
                    <div class="mlt-control-row">
                        <label>Height (px)</label>
                        <input type="text" name="mlt_options[load_more_height]" value="<?php echo esc_attr($c_lm_height); ?>" placeholder="Auto">
                    </div>
                </div>

                <div id="tab-viewbtn" class="mlt-tab-pane">
                    <div class="mlt-control-row">
                        <label>Label Text</label>
                        <input type="text" name="mlt_options[view_btn_label]" value="<?php echo esc_attr($c_vb_label); ?>">
                    </div>
                    <div class="mlt-control-row">
                        <label>Background Color</label>
                        <input type="color" name="mlt_options[view_btn_bg]" value="<?php echo esc_attr($c_vb_bg); ?>">
                    </div>
                    <div class="mlt-control-row">
                        <label>Text Color</label>
                        <input type="color" name="mlt_options[view_btn_text]" value="<?php echo esc_attr($c_vb_text); ?>">
                    </div>
                    <div class="mlt-control-row">
                        <label>Font Size (px)</label>
                        <input type="number" name="mlt_options[view_btn_size]" value="<?php echo esc_attr($c_vb_size); ?>" min="10">
                    </div>
                    <div class="mlt-control-row">
                        <label>Width (px)</label>
                        <input type="text" name="mlt_options[view_btn_width]" value="<?php echo esc_attr($c_vb_width); ?>" placeholder="Auto">
                    </div>
                    <div class="mlt-control-row">
                        <label>Height (px)</label>
                        <input type="text" name="mlt_options[view_btn_height]" value="<?php echo esc_attr($c_vb_height); ?>" placeholder="Auto">
                    </div>
                    <div class="mlt-control-row" style="grid-column: 1 / -1;">
                        <p class="description"><strong>Note:</strong> You can set a specific URL for each tab inside the "Menu Items" section below.</p>
                    </div>
                </div>
            </div>

            <div style="background:#fff; border-left:4px solid #46b450; padding:10px 15px; margin-bottom:15px; max-width:950px; margin-top:20px;">
                <p style="margin:0;"><strong>Two-Way Sync ON:</strong> Changing prices below updates WooCommerce.</p>
            </div>

            <a href="?page=mlt-settings&mlt_action=add_new_tab" class="button button-primary">+ Add New Tab Section</a>
            <br><br>

            <div id="mlt-accordion-wrapper">
                <?php
                if (!empty($tabs)) {
                    foreach ($tabs as $i => $tab) {
                        $title = isset($tab['title']) ? $tab['title'] : '';
                        $desc = isset($tab['desc']) ? $tab['desc'] : '';
                        $two_col = (isset($tab['two_col']) && $tab['two_col'] == '1') ? 'checked' : '';
                        $view_url = isset($tab['view_url']) ? $tab['view_url'] : '';
                        $items = isset($tab['items']) ? $tab['items'] : [];
                ?>
                        <div class="mlt-admin-box">
                            <div class="mlt-admin-header" onclick="this.parentElement.classList.toggle('open')">
                                <span>#<?php echo $i + 1; ?>: <?php echo esc_html($title); ?></span>
                                <span class="dashicons dashicons-arrow-down-alt2"></span>
                            </div>
                            <div class="mlt-admin-content">
                                <p><label><strong>Tab Name:</strong></label><br><input type="text" name="mlt_options[tabs][<?php echo $i; ?>][title]" value="<?php echo esc_attr($title); ?>" class="regular-text"></p>
                                <p><label><input type="checkbox" name="mlt_options[tabs][<?php echo $i; ?>][two_col]" value="1" <?php echo $two_col; ?>> <strong>Enable Two-Column Layout</strong></label></p>
                                <p><label><strong>Tab Description:</strong></label></p>
                                <?php wp_editor($desc, 'mlt_desc_' . $i, array('textarea_name' => "mlt_options[tabs][$i][desc]", 'media_buttons' => false, 'textarea_rows' => 3, 'teeny' => true)); ?>

                                <p style="margin-top:15px;"><label><strong>View More Button URL:</strong></label><br>
                                    <input type="text" name="mlt_options[tabs][<?php echo $i; ?>][view_url]" value="<?php echo esc_attr($view_url); ?>" class="regular-text" placeholder="https://example.com/full-menu">
                                    <br><small>Leave empty to hide button.</small>
                                </p>

                                <hr style="margin: 20px 0;">
                                <h3>Menu Items</h3>
                                <div class="mlt-items-container" data-tab="<?php echo $i; ?>">
                                    <?php
                                    if (!empty($items)) {
                                        foreach ($items as $j => $item) {
                                            $p_id = isset($item['product_id']) ? $item['product_id'] : '';
                                            $name = isset($item['name']) ? $item['name'] : '';
                                            $image = isset($item['image']) ? $item['image'] : '';
                                            $note = isset($item['note']) ? $item['note'] : '';
                                            $item_desc = isset($item['desc']) ? $item['desc'] : '';
                                            $current_price_val = ($p_id && isset($product_prices_map[$p_id])) ? $product_prices_map[$p_id] : '';
                                            if (empty($current_price_val) && isset($item['price'])) {
                                                $current_price_val = $item['price'];
                                            }

                                            $preview_src = $image ? $image : 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAxIDEiPjxyZWN0IHdpZHRoPSIxIiBoZWlnaHQ9IjEiIGZpbGw9IiNjY2MiLz48L3N2Zz4=';
                                    ?>
                                            <div class="mlt-item-row">
                                                <div style="flex: 2;"><label>Woo Product</label><select name="mlt_options[tabs][<?php echo $i; ?>][items][<?php echo $j; ?>][product_id]" class="mlt-product-select" onchange="mltUpdateInfo(this)"><?php echo str_replace('value="' . $p_id . '"', 'value="' . $p_id . '" selected', $product_options_html); ?></select></div>
                                                <div style="flex: 2;"><label>Display Name</label><input type="text" class="mlt-name-input" name="mlt_options[tabs][<?php echo $i; ?>][items][<?php echo $j; ?>][name]" value="<?php echo esc_attr($name); ?>"></div>
                                                <div style="flex: 1;"><label>Price</label><input type="text" class="mlt-price-input" name="mlt_options[tabs][<?php echo $i; ?>][items][<?php echo $j; ?>][price]" value="<?php echo esc_attr($current_price_val); ?>" placeholder="0.00"></div>

                                                <div style="flex: 2;">
                                                    <label>Item Image</label>
                                                    <div class="mlt-image-wrapper">
                                                        <img src="<?php echo esc_url($preview_src); ?>" class="mlt-image-preview">
                                                        <input type="hidden" name="mlt_options[tabs][<?php echo $i; ?>][items][<?php echo $j; ?>][image]" value="<?php echo esc_url($image); ?>" class="mlt-image-input">
                                                        <button type="button" class="button mlt-upload-btn">Upload</button>
                                                        <button type="button" class="button mlt-remove-img" style="<?php echo $image ? '' : 'display:none;'; ?>">x</button>
                                                    </div>
                                                </div>

                                                <div style="flex: 1;"><label>Short Note</label><input type="text" name="mlt_options[tabs][<?php echo $i; ?>][items][<?php echo $j; ?>][note]" value="<?php echo esc_attr($note); ?>" placeholder="Spicy"></div>
                                                <div style="flex-basis: 100%; margin-top: 5px;">
                                                    <label>Item Description</label>
                                                    <textarea name="mlt_options[tabs][<?php echo $i; ?>][items][<?php echo $j; ?>][desc]" rows="2" placeholder="Full details here..."><?php echo esc_textarea($item_desc); ?></textarea>
                                                </div>
                                                <div style="flex-basis:100%; text-align:right;"><span class="mlt-btn-remove" onclick="this.parentElement.parentElement.remove()">Remove Item</span></div>
                                            </div>
                                    <?php
                                        }
                                    }
                                    ?>
                                </div>
                                <button type="button" class="button" onclick="mltAddRow(<?php echo $i; ?>)">+ Add Item</button>
                                <div style="margin-top: 30px; border-top: 1px solid #eee; padding-top:10px;"><label style="color: red;"><input type="checkbox" name="mlt_options[tabs][<?php echo $i; ?>][remove]" value="1"> Delete Tab</label></div>
                            </div>
                        </div>
                <?php
                    }
                }
                ?>
            </div>
            <?php submit_button('Save Changes'); ?>
        </form>
    </div>
    <script>
        // ADMIN TAB SWITCHER
        function mltSwitchAdminTab(evt, tabId) {
            var i, tabcontent, tablinks;
            tabcontent = document.getElementsByClassName("mlt-tab-pane");
            for (i = 0; i < tabcontent.length; i++) {
                tabcontent[i].classList.remove('active');
            }
            tablinks = document.getElementsByClassName("mlt-tab-item");
            for (i = 0; i < tablinks.length; i++) {
                tablinks[i].classList.remove('active');
            }
            document.getElementById(tabId).classList.add('active');
            evt.currentTarget.classList.add('active');
        }

        var mltProductOptionsHTML = `<?php echo $product_options_html; ?>`;

        function mltAddRow(tabIndex) {
            var container = document.querySelector('.mlt-items-container[data-tab="' + tabIndex + '"]');
            var newIndex = container.querySelectorAll('.mlt-item-row').length + '_' + Date.now();
            var dummyImg = 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAxIDEiPjxyZWN0IHdpZHRoPSIxIiBoZWlnaHQ9IjEiIGZpbGw9IiNjY2MiLz48L3N2Zz4=';

            var html = `<div class="mlt-item-row">
                <div style="flex: 2;"><label>Woo Product</label><select name="mlt_options[tabs][${tabIndex}][items][${newIndex}][product_id]" class="mlt-product-select" onchange="mltUpdateInfo(this)">${mltProductOptionsHTML}</select></div>
                <div style="flex: 2;"><label>Display Name</label><input type="text" class="mlt-name-input" name="mlt_options[tabs][${tabIndex}][items][${newIndex}][name]" placeholder="Name"></div>
                <div style="flex: 1;"><label>Price</label><input type="text" class="mlt-price-input" name="mlt_options[tabs][${tabIndex}][items][${newIndex}][price]" placeholder="0.00"></div>
                <div style="flex: 2;">
                    <label>Item Image</label>
                    <div class="mlt-image-wrapper">
                        <img src="${dummyImg}" class="mlt-image-preview">
                        <input type="hidden" name="mlt_options[tabs][${tabIndex}][items][${newIndex}][image]" class="mlt-image-input">
                        <button type="button" class="button mlt-upload-btn">Upload</button>
                        <button type="button" class="button mlt-remove-img" style="display:none;">x</button>
                    </div>
                </div>
                <div style="flex: 1;"><label>Short Note</label><input type="text" name="mlt_options[tabs][${tabIndex}][items][${newIndex}][note]" placeholder="Spicy"></div>
                <div style="flex-basis: 100%; margin-top: 5px;"><label>Item Description</label><textarea name="mlt_options[tabs][${tabIndex}][items][${newIndex}][desc]" rows="2" placeholder="Full details here..."></textarea></div>
                <div style="flex-basis:100%; text-align:right;"><span class="mlt-btn-remove" onclick="this.parentElement.parentElement.remove()">Remove Item</span></div></div>`;
            var tempDiv = document.createElement('div');
            tempDiv.innerHTML = html;
            container.appendChild(tempDiv.firstElementChild);
        }

        function mltUpdateInfo(selectElement) {
            var row = selectElement.closest('.mlt-item-row');
            var selected = selectElement.options[selectElement.selectedIndex];
            if (selectElement.value !== "") {
                if (row.querySelector('.mlt-name-input').value === "") row.querySelector('.mlt-name-input').value = selected.text;
                if (selected.getAttribute('data-price')) row.querySelector('.mlt-price-input').value = selected.getAttribute('data-price');
            }
        }

        // Toggle Sidebar Color Option
        document.getElementById('mlt-layout-select').addEventListener('change', function() {
            var row = document.getElementById('mlt-sidebar-bg-row');
            if (this.value === 'vertical') {
                row.classList.remove('mlt-hidden');
            } else {
                row.classList.add('mlt-hidden');
            }
        });

        jQuery(document).ready(function($) {
            var mediaUploader;
            $(document).on('click', '.mlt-upload-btn', function(e) {
                e.preventDefault();
                var button = $(this);
                var wrapper = button.closest('.mlt-image-wrapper');
                if (mediaUploader) {
                    mediaUploader.open();
                    mediaUploader.off('select');
                    mediaUploader.on('select', function() {
                        var attachment = mediaUploader.state().get('selection').first().toJSON();
                        wrapper.find('.mlt-image-input').val(attachment.url);
                        wrapper.find('.mlt-image-preview').attr('src', attachment.url);
                        wrapper.find('.mlt-remove-img').show();
                    });
                    return;
                }
                mediaUploader = wp.media.frames.file_frame = wp.media({
                    title: 'Choose Image',
                    button: {
                        text: 'Choose Image'
                    },
                    multiple: false
                });
                mediaUploader.on('select', function() {
                    var attachment = mediaUploader.state().get('selection').first().toJSON();
                    wrapper.find('.mlt-image-input').val(attachment.url);
                    wrapper.find('.mlt-image-preview').attr('src', attachment.url);
                    wrapper.find('.mlt-remove-img').show();
                });
                mediaUploader.open();
            });
            $(document).on('click', '.mlt-remove-img', function(e) {
                e.preventDefault();
                var wrapper = $(this).closest('.mlt-image-wrapper');
                wrapper.find('.mlt-image-input').val('');
                wrapper.find('.mlt-image-preview').attr('src', 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAxIDEiPjxyZWN0IHdpZHRoPSIxIiBoZWlnaHQ9IjEiIGZpbGw9IiNjY2MiLz48L3N2Zz4=');
                $(this).hide();
            });
        });
    </script>
<?php
}

// ------------------------------------------------------------------
// 6. FRONTEND
// ------------------------------------------------------------------
function mlt_render_tab_menu()
{
    $options = get_option('mlt_options');
    $tabs = $options['tabs'] ?? [];
    if (empty($tabs)) return '';

    // Config
    $c_btn_bg     = $options['btn_bg'] ?? '#222222';
    $c_btn_text   = $options['btn_text'] ?? '#ffffff';
    $c_tab_active = $options['tab_active'] ?? '#0073aa';
    $c_content_bg = $options['content_bg'] ?? '#ffffff';
    $c_wrapper_bg = $options['wrapper_bg'] ?? '';
    $c_tab_bg     = $options['tab_bg'] ?? '#ffffff';
    $c_sidebar_bg = $options['sidebar_bg'] ?? '#f8f9fa';
    $c_border_col = $options['border_col'] ?? '#eeeeee';
    $c_wrap_border = $options['wrap_border'] ?? '';
    $c_cont_border = $options['cont_border'] ?? '#f9f9f9';
    $c_name_col   = $options['name_col'] ?? '#333333';
    $c_price_col  = $options['price_col'] ?? '#0073aa';
    $c_desc_col   = $options['desc_col'] ?? '#777777';
    $c_note_col   = $options['note_col'] ?? '#555555';
    $c_main_desc_col = $options['main_desc_col'] ?? '#555555';
    $c_font_size  = $options['font_size'] ?? 17;
    $c_tab_font_size = $options['tab_font_size'] ?? 15;
    $c_btn_label  = $options['btn_label'] ?? 'Add';
    $c_layout_mode = $options['layout_mode'] ?? 'horizontal';

    $c_btn_width  = $options['btn_width'] ?? '';
    $c_btn_height = $options['btn_height'] ?? '';

    // Load More (Pagination)
    $c_lm_enable = (isset($options['load_more_enable']) && $options['load_more_enable'] == '1');
    $c_lm_label = $options['load_more_label'] ?? 'Load More';
    $c_lm_bg    = $options['load_more_bg'] ?? '#f1f1f1';
    $c_lm_text  = $options['load_more_text'] ?? '#333333';
    $c_lm_size  = $options['load_more_size'] ?? 14;
    $c_lm_width = $options['load_more_width'] ?? '';
    $c_lm_height = $options['load_more_height'] ?? '';

    // View Button (URL)
    $c_vb_label = $options['view_btn_label'] ?? 'View Full Menu';
    $c_vb_bg    = $options['view_btn_bg'] ?? '#222';
    $c_vb_text  = $options['view_btn_text'] ?? '#fff';
    $c_vb_size  = $options['view_btn_size'] ?? 14;
    $c_vb_width = $options['view_btn_width'] ?? '';
    $c_vb_height = $options['view_btn_height'] ?? '';

    ob_start();
?>
    <style>
        .mlt-container {
            font-family: 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
            background: <?php echo $c_wrapper_bg ? $c_wrapper_bg : 'transparent'; ?>;
            padding: 20px;
            border-radius: 12px;
            margin-bottom: 60px;
            /* Space for floating cart */
            border: <?php echo $c_wrap_border ? '1px solid ' . $c_wrap_border : 'none'; ?>;
        }

        :focus-visible {
            outline: 2px solid <?php echo $c_tab_active; ?>;
            outline-offset: 2px;
        }

        /* SEARCH BAR */
        .mlt-search-wrapper {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            position: relative;
            align-items: center;
        }

        .mlt-search-wrapper input {
            width: 100%;
            padding: 12px 20px;
            border-radius: 50px;
            border: 1px solid #ddd;
            font-size: 15px;
            outline: none;
            transition: 0.3s;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.03);
        }

        .mlt-search-wrapper input:focus {
            border-color: <?php echo $c_tab_active; ?>;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
        }

        .mlt-mic-btn {
            background: #fff;
            border: 1px solid #ddd;
            border-radius: 50%;
            width: 46px;
            height: 46px;
            cursor: pointer;
            color: #555;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: 0.3s;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
            flex-shrink: 0;
        }

        .mlt-mic-btn:hover {
            color: <?php echo $c_tab_active; ?>;
            transform: scale(1.05);
        }

        .mlt-mic-btn.listening {
            background: #f44336;
            color: #fff;
            border-color: #f44336;
            animation: mltPulse 1.5s infinite;
        }

        @keyframes mltPulse {
            0% {
                box-shadow: 0 0 0 0 rgba(244, 67, 54, 0.7);
            }

            70% {
                box-shadow: 0 0 0 10px rgba(244, 67, 54, 0);
            }

            100% {
                box-shadow: 0 0 0 0 rgba(244, 67, 54, 0);
            }
        }

        /* TOOLTIP */
        .mlt-tooltip-wrap {
            position: relative;
            display: inline-flex;
            align-items: center;
            margin-left: 8px;
        }

        .mlt-info-icon {
            font-size: 20px;
            color: #aaa;
            cursor: pointer;
            transition: 0.3s;
        }

        .mlt-info-icon:hover {
            color: <?php echo $c_tab_active; ?>;
        }

        .mlt-tooltip-box {
            position: absolute;
            top: 35px;
            right: 0;
            width: 220px;
            background: #fff;
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.15);
            z-index: 999;
            opacity: 0;
            visibility: hidden;
            transition: 0.3s;
            text-align: left;
            font-size: 13px;
            line-height: 1.5;
            color: #555;
            border: 1px solid #eee;
        }

        .mlt-tooltip-wrap:hover .mlt-tooltip-box {
            opacity: 1;
            visibility: visible;
            top: 30px;
        }

        .mlt-tooltip-box h4 {
            margin: 0 0 8px 0;
            font-size: 14px;
            color: #333;
        }

        .mlt-tooltip-box p {
            margin: 0 0 5px 0;
        }

        /* LAYOUT */
        .mlt-layout-wrapper {
            display: flex;
            flex-direction: column;
            gap: 0;
        }

        /* TABS */
        .mlt-tab {
            display: flex;
            flex-wrap: nowrap;
            overflow-x: auto;
            margin-bottom: 20px;
            padding: 5px;
            gap: 12px;
            -webkit-overflow-scrolling: touch;
            scrollbar-width: none;
        }

        .mlt-tab::-webkit-scrollbar {
            display: none;
        }

        .mlt-tab button {
            background: <?php echo $c_tab_bg; ?>;
            border: 1px solid #eee;
            outline: none;
            cursor: pointer;
            padding: 10px 24px;
            font-size: <?php echo $c_tab_font_size; ?>px;
            font-weight: 600;
            color: #555;
            transition: all 0.3s ease;
            border-radius: 50px;
            white-space: nowrap;
            flex: 0 0 auto;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
        }

        .mlt-tab button:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            color: #333;
        }

        .mlt-tab button.active {
            background-color: <?php echo $c_tab_active; ?>;
            color: #fff;
            border-color: <?php echo $c_tab_active; ?>;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
        }

        /* VERTICAL LAYOUT */
        <?php if ($c_layout_mode === 'vertical'): ?>@media (min-width: 769px) {
            .mlt-layout-wrapper {
                flex-direction: row;
                align-items: flex-start;
                gap: 30px;
            }

            .mlt-tab {
                flex-direction: column;
                width: 250px;
                flex-shrink: 0;
                overflow-y: auto;
                overflow-x: hidden;
                padding: 15px;
                margin-bottom: 0;
                border-radius: 8px;
                background-color: <?php echo $c_sidebar_bg; ?>;
            }

            .mlt-tab button {
                width: 100%;
                text-align: left;
                margin-bottom: 10px;
                border-radius: 8px;
            }

            .mlt-content-area {
                flex-grow: 1;
                width: 100%;
            }
        }

        <?php endif; ?>

        /* CONTENT */
        .mlt-tabcontent {
            display: none;
            background: <?php echo $c_content_bg; ?>;
            border-radius: 12px;
            padding: 35px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.06);
            border: 1px solid <?php echo $c_cont_border; ?>;
            animation: mltFade 0.4s ease-out;
        }

        @keyframes mltFade {
            from {
                opacity: 0;
                transform: translateY(10px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .mlt-desc {
            margin-bottom: 25px;
            color: <?php echo $c_main_desc_col; ?>;
            line-height: 1.6;
            font-size: 1.05em;
        }

        .mlt-menu-list {
            list-style: none;
            padding: 0;
            margin: 0;
            display: block;
        }

        .mlt-menu-list.mlt-grid-view {
            display: grid;
            grid-template-columns: 1fr 1fr;
            column-gap: 40px;
            row-gap: 0;
        }

        .mlt-menu-item {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            padding: 20px 0;
            border-bottom: 1px dashed <?php echo $c_border_col; ?>;
            position: relative;
            height: fit-content;
        }

        .mlt-menu-item:last-child {
            border-bottom: none;
        }

        .mlt-menu-item.hidden {
            display: none !important;
        }

        .mlt-item-image {
            width: 60px;
            height: 60px;
            object-fit: cover;
            border-radius: 8px;
            margin-right: 15px;
            border: 1px solid #eee;
            flex-shrink: 0;
        }

        .mlt-item-name {
            font-weight: 700;
            font-size: <?php echo $c_font_size; ?>px;
            color: <?php echo $c_name_col; ?>;
            flex-grow: 1;
            padding-right: 20px;
            display: block;
        }

        .mlt-item-note {
            display: inline-block;
            font-size: 12px;
            background: #eee;
            padding: 2px 6px;
            border-radius: 4px;
            color: <?php echo $c_note_col; ?>;
            margin-left: 8px;
            vertical-align: middle;
            font-weight: normal;
        }

        .mlt-item-desc {
            display: block;
            font-size: 14px;
            color: <?php echo $c_desc_col; ?>;
            margin-bottom: 6px;
            line-height: 1.4;
            padding-right: 10px;
        }

        .mlt-right {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-top: 5px;
            flex-shrink: 0;
        }

        .mlt-price {
            font-weight: 700;
            color: <?php echo $c_price_col; ?>;
            font-size: <?php echo $c_font_size; ?>px;
            white-space: nowrap;
        }

        .mlt-right .button {
            background-color: <?php echo $c_btn_bg; ?> !important;
            color: <?php echo $c_btn_text; ?> !important;
            border-radius: 6px !important;
            padding: 8px 20px !important;
            font-size: 13px !important;
            font-weight: 600 !important;
            border: none !important;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            transition: all 0.2s !important;
            line-height: 1 !important;
            white-space: nowrap;
            /* Dimensions */
            <?php if ($c_btn_width): ?>width: <?php echo $c_btn_width; ?>px !important;
            <?php endif; ?><?php if ($c_btn_height): ?>height: <?php echo $c_btn_height; ?>px !important;
            display: flex !important;
            align-items: center !important;
            justify-content: center !important;
            <?php endif; ?>
        }

        .mlt-right .button:hover {
            opacity: 0.9;
            transform: translateY(-1px);
        }

        .mlt-right .button.mlt-added-success {
            background-color: #46b450 !important;
            color: #fff !important;
            pointer-events: none;
        }

        /* FLOATING CART */
        .mlt-floating-cart {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: <?php echo $c_btn_bg; ?>;
            /* Match button color */
            color: <?php echo $c_btn_text; ?>;
            padding: 15px 20px;
            box-shadow: 0 -5px 20px rgba(0, 0, 0, 0.15);
            z-index: 999999;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-weight: bold;
            font-size: 16px;
            transform: translateY(100%);
            transition: transform 0.4s ease-out;
        }

        .mlt-floating-cart.mlt-visible {
            transform: translateY(0);
        }

        .mlt-cart-right-group {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .mlt-floating-cart a {
            color: inherit;
            text-decoration: none;
            border: 1px solid rgba(255, 255, 255, 0.3);
            padding: 5px 15px;
            border-radius: 4px;
            font-size: 14px;
        }

        .mlt-floating-cart a:hover {
            background: rgba(255, 255, 255, 0.1);
        }

        .mlt-cart-close {
            font-size: 24px;
            line-height: 1;
            cursor: pointer;
            opacity: 0.8;
        }

        .mlt-cart-close:hover {
            opacity: 1;
        }

        #mlt-success-popup {
            position: fixed;
            bottom: 80px;
            left: 50%;
            transform: translateX(-50%) translateY(100px);
            background-color: #333;
            color: #fff;
            padding: 12px 25px;
            border-radius: 50px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.2);
            font-size: 15px;
            z-index: 1000000;
            opacity: 0;
            transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            display: flex;
            align-items: center;
            gap: 10px;
        }

        #mlt-success-popup.show {
            transform: translateX(-50%) translateY(0);
            opacity: 1;
        }

        #mlt-success-popup svg {
            width: 20px;
            height: 20px;
            fill: #46b450;
        }

        /* LOAD MORE BUTTON */
        .mlt-load-more-btn {
            display: block;
            margin: 20px auto 0;
            background: <?php echo $c_lm_bg; ?>;
            color: <?php echo $c_lm_text; ?>;
            font-size: <?php echo $c_lm_size; ?>px;
            border: none;
            padding: 10px 25px;
            border-radius: 50px;
            cursor: pointer;
            font-weight: 600;
            transition: opacity 0.3s;
            <?php if ($c_lm_width): ?>width: <?php echo $c_lm_width; ?>px;
            <?php endif; ?><?php if ($c_lm_height): ?>height: <?php echo $c_lm_height; ?>px;
            display: flex;
            align-items: center;
            justify-content: center;
            <?php endif; ?>
        }

        .mlt-load-more-btn:hover {
            opacity: 0.9;
        }

        /* VIEW BUTTON */
        .mlt-view-more-btn {
            display: block;
            margin: 20px auto 0;
            text-align: center;
            text-decoration: none;
            background: <?php echo $c_vb_bg; ?>;
            color: <?php echo $c_vb_text; ?>;
            font-size: <?php echo $c_vb_size; ?>px;
            border: none;
            padding: 10px 25px;
            border-radius: 50px;
            cursor: pointer;
            font-weight: 600;
            transition: opacity 0.3s;
            <?php if ($c_vb_width): ?>width: <?php echo $c_vb_width; ?>px;
            margin-left: auto;
            margin-right: auto;
            <?php endif; ?><?php if ($c_vb_height): ?>height: <?php echo $c_vb_height; ?>px;
            display: flex;
            align-items: center;
            justify-content: center;
            <?php endif; ?>
        }

        .mlt-view-more-btn:hover {
            opacity: 0.9;
            color: <?php echo $c_vb_text; ?>;
        }

        @media (max-width: 768px) {
            .mlt-menu-list.mlt-grid-view {
                grid-template-columns: 1fr;
            }

            .mlt-menu-item {
                flex-direction: column;
                align-items: flex-start;
                gap: 8px;
            }

            .mlt-right {
                width: 100%;
                justify-content: space-between;
                margin-top: 10px;
            }
        }
    </style>

    <div class="mlt-container">
        <div class="mlt-search-wrapper">
            <input type="text" id="mlt-search-input" placeholder="Search menu or say 'Add Burger'..." aria-label="Search menu items">
            <button id="mlt-mic-btn" class="mlt-mic-btn" title="Voice Command" aria-label="Use voice search">
                <span class="dashicons dashicons-microphone"></span>
            </button>
            <div class="mlt-tooltip-wrap">
                <span class="dashicons dashicons-editor-help mlt-info-icon" tabindex="0" role="button" aria-label="Voice Command Help"></span>
                <div class="mlt-tooltip-box">
                    <h4>Voice & Search Help</h4>
                    <p><strong>Search:</strong> Type to filter items instantly.</p>
                    <p><strong>Navigate:</strong> Say <em>"Show Salads"</em> or <em>"Open Drinks"</em>.</p>
                    <p><strong>Order:</strong> Say <em>"Add Burger"</em> to add to cart.</p>
                </div>
            </div>
        </div>

        <div class="mlt-layout-wrapper">
            <div class="mlt-tab" role="tablist" aria-label="Menu Sections">
                <?php foreach ($tabs as $index => $tab):
                    $active = ($index === 0) ? 'active' : '';
                    $aria_selected = ($index === 0) ? 'true' : 'false';
                ?>
                    <button class="mlt-links <?php echo $active; ?>"
                        role="tab"
                        aria-selected="<?php echo $aria_selected; ?>"
                        aria-controls="mlt-tab-<?php echo $index; ?>"
                        id="mlt-tab-link-<?php echo $index; ?>"
                        onclick="mltOpenTab(event, 'mlt-tab-<?php echo $index; ?>')">
                        <?php echo esc_html($tab['title']); ?>
                    </button>
                <?php endforeach; ?>
            </div>

            <div class="mlt-content-area">
                <?php foreach ($tabs as $index => $tab):
                    $display = ($index === 0) ? 'block' : 'none';
                    $grid_class = (isset($tab['two_col']) && $tab['two_col'] == '1') ? 'mlt-grid-view' : '';
                ?>
                    <div id="mlt-tab-<?php echo $index; ?>"
                        class="mlt-tabcontent"
                        role="tabpanel"
                        aria-labelledby="mlt-tab-link-<?php echo $index; ?>"
                        style="display:<?php echo $display; ?>;">

                        <?php if (!empty($tab['desc'])): ?>
                            <div class="mlt-desc"><?php echo wp_kses_post($tab['desc']); ?></div>
                        <?php endif; ?>

                        <ul class="mlt-menu-list <?php echo $grid_class; ?>">
                            <?php
                            if (!empty($tab['items'])):
                                foreach ($tab['items'] as $item):
                                    $product_id = isset($item['product_id']) ? intval($item['product_id']) : 0;
                                    $custom_name = isset($item['name']) ? $item['name'] : '';
                                    $image = isset($item['image']) ? $item['image'] : '';
                                    $note = isset($item['note']) ? $item['note'] : '';
                                    $item_desc = isset($item['desc']) ? $item['desc'] : '';

                                    $display_price = '';
                                    if ($product_id > 0 && function_exists('wc_get_product')) {
                                        $product = wc_get_product($product_id);
                                        if ($product) {
                                            $display_price = $product->get_price_html();
                                        }
                                    }
                            ?>
                                    <li class="mlt-menu-item">
                                        <?php if (!empty($image)): ?>
                                            <img src="<?php echo esc_url($image); ?>" class="mlt-item-image" alt="<?php echo esc_attr($custom_name); ?>">
                                        <?php endif; ?>

                                        <div style="flex-grow: 1;">
                                            <?php if (!empty($item_desc)): ?>
                                                <span class="mlt-item-desc"><?php echo nl2br(esc_html($item_desc)); ?></span>
                                            <?php endif; ?>

                                            <span class="mlt-item-name">
                                                <?php echo esc_html($custom_name); ?>
                                                <?php if (!empty($note)): ?>
                                                    <span class="mlt-item-note"><?php echo esc_html($note); ?></span>
                                                <?php endif; ?>
                                            </span>
                                        </div>

                                        <div class="mlt-right">
                                            <span class="mlt-price"><?php echo wp_kses_post($display_price); ?></span>
                                            <?php
                                            if ($product_id > 0 && function_exists('wc_get_product')) {
                                                echo sprintf(
                                                    '<a href="%s" data-quantity="1" class="%s" %s data-original-text="%s" aria-label="Add %s to cart">%s</a>',
                                                    esc_url('?add-to-cart=' . $product_id),
                                                    'button product_type_simple add_to_cart_button ajax_add_to_cart',
                                                    'data-product_id="' . $product_id . '" rel="nofollow"',
                                                    esc_attr($c_btn_label),
                                                    esc_attr($custom_name),
                                                    esc_html($c_btn_label)
                                                );
                                            }
                                            ?>
                                        </div>
                                    </li>
                            <?php endforeach;
                            endif; ?>
                        </ul>

                        <?php if ($c_lm_enable): ?>
                            <button class="mlt-load-more-btn" style="display:none;"><?php echo esc_html($c_lm_label); ?></button>
                        <?php endif; ?>

                        <?php
                        $view_url = isset($tab['view_url']) ? $tab['view_url'] : '';
                        if (!empty($view_url)): ?>
                            <a href="<?php echo esc_url($view_url); ?>" class="mlt-view-more-btn"><?php echo esc_html($c_vb_label); ?></a>
                        <?php endif; ?>

                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="mlt-floating-cart <?php echo (function_exists('WC') && !WC()->cart->is_empty()) ? 'mlt-visible' : ''; ?>">
            <span class="mlt-cart-info">
                <span class="mlt-cart-count"><?php echo (function_exists('WC') ? WC()->cart->get_cart_contents_count() : 0); ?> Items</span> &ndash;
                <span class="mlt-cart-total"><?php echo (function_exists('WC') ? WC()->cart->get_cart_total() : ''); ?></span>
            </span>
            <div class="mlt-cart-right-group">
                <a href="<?php echo esc_url(wc_get_cart_url()); ?>">View Cart &rarr;</a>
                <span class="mlt-cart-close" title="Close">&times;</span>
            </div>
        </div>

        <div id="mlt-success-popup" role="alert" aria-live="polite">
            <svg viewBox="0 0 24 24">
                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z" />
            </svg>
            <span id="mlt-popup-msg">Item added to cart!</span>
        </div>
    </div>

    <script>
        function mltOpenTab(evt, tabId) {
            var i, tabcontent, tablinks;
            var container = evt.currentTarget.closest('.mlt-container');

            tabcontent = container.getElementsByClassName("mlt-tabcontent");
            for (i = 0; i < tabcontent.length; i++) {
                tabcontent[i].style.display = "none";
            }

            tablinks = container.getElementsByClassName("mlt-links");
            for (i = 0; i < tablinks.length; i++) {
                tablinks[i].classList.remove("active");
                tablinks[i].setAttribute('aria-selected', 'false');
            }

            var tabEl = container.querySelector("#" + tabId);
            if (tabEl) {
                tabEl.style.display = "block";

                // Re-init Load More for this tab
                mltInitLoadMore(tabEl);

                if (evt.target && evt.target.classList.contains('mlt-links')) {
                    evt.target.classList.add('active');
                    evt.target.setAttribute('aria-selected', 'true');
                    evt.target.scrollIntoView({
                        behavior: 'smooth',
                        inline: 'center',
                        block: 'nearest'
                    });
                } else {
                    var btnId = tabId.replace('mlt-tab-', 'mlt-tab-link-');
                    var btn = document.getElementById(btnId);
                    if (btn) {
                        btn.classList.add('active');
                        btn.setAttribute('aria-selected', 'true');
                        btn.scrollIntoView({
                            behavior: 'smooth',
                            inline: 'center',
                            block: 'nearest'
                        });
                    }
                }
            }
        }

        // --- LOAD MORE LOGIC ---
        function mltInitLoadMore(tabContent) {
            // Only apply if NOT searching
            if (jQuery('#mlt-search-input').val().trim() !== '') return;

            var items = jQuery(tabContent).find('.mlt-menu-item');
            var btn = jQuery(tabContent).find('.mlt-load-more-btn');

            if (btn.length === 0) return; // Feature disabled

            // If > 6 items, hide rest and show button
            if (items.length > 6) {
                items.hide();
                items.slice(0, 6).show();
                btn.show();
            } else {
                items.show();
                btn.hide();
            }
        }

        document.addEventListener('DOMContentLoaded', function() {
            var tabLists = document.querySelectorAll('.mlt-tab');
            tabLists.forEach(function(list) {
                list.addEventListener('keydown', function(e) {
                    var tabs = Array.from(list.querySelectorAll('[role="tab"]'));
                    var index = tabs.indexOf(document.activeElement);
                    if (index === -1) return;
                    var nextIndex = null;
                    if (e.key === 'ArrowRight') nextIndex = (index + 1) % tabs.length;
                    else if (e.key === 'ArrowLeft') nextIndex = (index - 1 + tabs.length) % tabs.length;
                    else if (e.key === 'Home') nextIndex = 0;
                    else if (e.key === 'End') nextIndex = tabs.length - 1;
                    if (nextIndex !== null) {
                        e.preventDefault();
                        tabs[nextIndex].focus();
                        tabs[nextIndex].click();
                    }
                });
            });
        });

        jQuery(document).ready(function($) {

            // --- LOAD MORE CLICK ---
            $('.mlt-load-more-btn').on('click', function() {
                var container = $(this).closest('.mlt-tabcontent');
                var hiddenItems = container.find('.mlt-menu-item:hidden');

                // Show next 6
                hiddenItems.slice(0, 6).slideDown();

                // If no more hidden, hide button
                if (container.find('.mlt-menu-item:hidden').length <= 6) {
                    $(this).fadeOut();
                }
            });

            // Initial Load for visible tab
            $('.mlt-tabcontent:visible').each(function() {
                mltInitLoadMore(this);
            });

            // --- SEARCH LOGIC ---
            $('#mlt-search-input').on('keyup', function() {
                var value = $(this).val().toLowerCase();

                // If searching, disable Load More logic (Show All matches)
                if (value !== "") {
                    $('.mlt-load-more-btn').hide();
                    $('.mlt-menu-item').each(function() {
                        var text = $(this).text().toLowerCase();
                        if (text.indexOf(value) > -1) {
                            $(this).removeClass('hidden').show(); // Force show
                        } else {
                            $(this).addClass('hidden').hide();
                        }
                    });
                } else {
                    // Search cleared: Reset current tab to pagination view
                    $('.mlt-menu-item').removeClass('hidden'); // Remove search hidden class
                    var activeTab = $('.mlt-tabcontent:visible');
                    mltInitLoadMore(activeTab);
                }
            });

            if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
                var SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
                var recognition = new SpeechRecognition();
                recognition.continuous = false;
                recognition.lang = 'en-US';

                $('#mlt-mic-btn').on('click', function() {
                    if ($(this).hasClass('listening')) {
                        recognition.stop();
                    } else {
                        recognition.start();
                    }
                });

                recognition.onstart = function() {
                    $('#mlt-mic-btn').addClass('listening');
                    $('#mlt-search-input').attr('placeholder', 'Listening...');
                };
                recognition.onend = function() {
                    $('#mlt-mic-btn').removeClass('listening');
                    $('#mlt-search-input').attr('placeholder', 'Search or say command...');
                };

                recognition.onresult = function(event) {
                    var transcript = event.results[0][0].transcript.toLowerCase().trim();
                    $('#mlt-search-input').val(transcript);

                    var foundTab = false;
                    $('.mlt-links').each(function() {
                        var tabName = $(this).text().toLowerCase().trim();
                        if (transcript.includes(tabName) || tabName.includes(transcript.replace('show', '').replace('open', '').trim())) {
                            $(this)[0].click();
                            foundTab = true;
                            return false;
                        }
                    });

                    if (!foundTab) {
                        if (transcript.includes('add') || transcript.includes('order')) {
                            var target = transcript.replace('add', '').replace('order', '').trim();
                            var foundItem = false;
                            $('.mlt-item-name').each(function() {
                                var itemName = $(this).text().toLowerCase().trim();
                                if (itemName.includes(target) || target.includes(itemName)) {
                                    $(this).closest('.mlt-menu-item').find('.ajax_add_to_cart')[0].click();
                                    foundItem = true;
                                    return false;
                                }
                            });
                            if (!foundItem) $('#mlt-search-input').trigger('keyup');
                        } else {
                            $('#mlt-search-input').trigger('keyup');
                        }
                    }
                };
            } else {
                $('#mlt-mic-btn').hide();
            }

            var lastClickedItemName = "";
            $(document).on('click', '.mlt-right .ajax_add_to_cart', function() {
                var row = $(this).closest('.mlt-menu-item');
                lastClickedItemName = row.find('.mlt-item-name').contents().filter(function() {
                    return this.nodeType == 3;
                }).text().trim();
            });
            $(document.body).on('added_to_cart', function(event, fragments, cart_hash, $button) {
                if ($button && $button.closest('.mlt-container').length > 0) {
                    var originalText = $button.data('original-text') || "Add";
                    $button.text('Added');
                    $button.addClass('mlt-added-success');
                    var popup = $('#mlt-success-popup');
                    var msgSpan = $('#mlt-popup-msg');
                    if (lastClickedItemName) {
                        msgSpan.html("<strong>" + lastClickedItemName + "</strong> added to cart!");
                    } else {
                        msgSpan.text("Item added to cart!");
                    }
                    popup.addClass('show');
                    setTimeout(function() {
                        $button.text(originalText);
                        $button.removeClass('mlt-added-success');
                        popup.removeClass('show');
                    }, 3000);
                }
            });

            // CART CLOSE LOGIC
            $(document).on('click', '.mlt-cart-close', function(e) {
                e.preventDefault();
                $('.mlt-floating-cart').removeClass('mlt-visible');
            });
        });
    </script>
<?php
    return ob_get_clean();
}
add_shortcode('menu_list_table', 'mlt_render_tab_menu');
